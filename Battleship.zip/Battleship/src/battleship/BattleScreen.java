package battleship;

import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.WindowConstants;

//@authors: borisks & damyanlh
public class BattleScreen extends javax.swing.JFrame {

    //for scene
    private JLayeredPane layeredPane = new JLayeredPane();
    private JLabel background = new JLabel();
    private ImageIcon redX;
    private ImageIcon whiteX;
    private ImageIcon grayButton;
    private ImageIcon colorButton;

    //label arrays
    private DynamicLabelArray xLabels = new DynamicLabelArray(0);

    //for adding ships
    private int strikes = 20;
    private Player player = new Player();
    private boolean strikePhase = true;

    //for next phase
    private JLabel nextTurn = new JLabel(grayButton);
    private JLabel strikeCounter = new JLabel(strikes + "");

    public BattleScreen(Player player) {
        this.player = player;
        this.setBounds(100, 100, 900, 720);
        //inicializirane 

        // <editor-fold defaultstate="collapsed" desc="nextTurn">
        nextTurn.setBounds(760, 100, 100, 50);
        nextTurn.setOpaque(true);
        nextTurn.setFont(new Font("Comic Sans", Font.BOLD, 20));
        nextTurn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!strikePhase) {
                    switchScene();
                }
            }
        });
        // </editor-fold>

        // <editor-fold defaultstate="collapsed" desc="strikeCounter">
        strikeCounter.setBounds(1150, 10, 50, 50);
        strikeCounter.setOpaque(false);
        strikeCounter.setFont(new Font("Comic Sans", Font.BOLD, 40));
        // </editor-fold>  

        // <editor-fold defaultstate="collapsed" desc="background">
        ImageIcon backgroundIcon = new ImageIcon("src/images/StrikeArea.png");
        layeredPane.setBounds(0, 0, 900, 720);
        background.setIcon(backgroundIcon);
        background.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());
        // </editor-fold>

        this.setLayeredPane(layeredPane);
        this.revalidate();

        layeredPane.add(strikeCounter, Integer.valueOf(5));
        layeredPane.add(background, Integer.valueOf(0));
        for (int i = 0; i < xLabels.length(); i++) {
            layeredPane.add(xLabels.elementGetter(i), Integer.valueOf(1));
        }
        this.addKeyListener(new MKeyListener());
        this.addMouseListener(new MouseAdapterForCrossSpawning());
        this.setBounds(100, 100, 900, 720);
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }

    private void switchScene() {
        if (PlayerScreen.getCurrentPhase() == 0) {
            PlayerScreen.setP1(player);
            PlayerScreen.setCurrentPhase(1);
            this.dispose();
            new PlayerScreen().run();
        } else if (PlayerScreen.getCurrentPhase() == 1) {
            PlayerScreen.setP2(player);
            PlayerScreen.setCurrentPhase(2);
            this.dispose();
            new PlayerScreen().run();
        }
    }

    class DynamicLabelArray {

        private JLabel[] shipLabels = new JLabel[0];

        public DynamicLabelArray(int length) {
            shipLabels = new JLabel[length];
            for (int i = 0; i < shipLabels.length; i++) {
                shipLabels[i] = new JLabel();
                shipLabels[i].setBounds(0, 0, 1, 1);
            }
        }

        public void setshipLabels(JLabel[] arr) {
            for (int i = 0; i < shipLabels.length; i++) {
                this.shipLabels[i] = arr[i];
            }
        }

        public void addLabel() {
            JLabel[] arr = new JLabel[shipLabels.length + 1];
            for (int i = 0; i < shipLabels.length; i++) {
                arr[i] = shipLabels[i];

            }
            shipLabels = new JLabel[arr.length];
            setshipLabels(arr);
        }

        public void removeLabel(int elementNumber) {

            if (elementNumber >= 0 && elementNumber < shipLabels.length) {
                JLabel[] arr = new JLabel[shipLabels.length - 1];
                for (int i = 0, y = 0; i < shipLabels.length; i++, y++) {

                    if (i == elementNumber) {
                        shipLabels[i].setVisible(false);

                        if (elementNumber == shipLabels.length - 1) {

                        } else {
                            y--;
                        }
                    } else {
                        arr[y] = shipLabels[i];
                    }

                }
                shipLabels = new JLabel[arr.length];
                setshipLabels(arr);

            } else {
                System.out.println("Error: not able to remove element out of array length");
            }
        }

        public int length() {
            return shipLabels.length;
        }

        public void spawnX(int numberInArray, int x, int y) {
            shipLabels[numberInArray] = new JLabel();
            //tuk se slaga saotvetnia X ako si ocelil ili ne
            /*
            shipLabels[numberInArray].setIcon((Icon) hasHit(x,y));
            shipLabels[numberInArray].setBounds(x, y, width, height);
            shipLabels[numberInArray].setOpaque(false);
            layeredPane.add(shipLabels[numberInArray], Integer.valueOf(2));
             */
            layeredPane.revalidate();
        }

        public JLabel elementGetter(int numberInArray) {
            return shipLabels[numberInArray];
        }

    }
    class MKeyListener extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent event) {

            char ch = event.getKeyChar();  
            if (ch == 'z' || ch == 'Z') {
                
            }
        }
    }
    class MouseAdapterForCrossSpawning extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
           
        }

        
    }
}
